 <link rel="stylesheet" type="text/css" href="Css/MainPageCss/MpproductSlider.css?v=<?php echo time(); ?>">
 <section>
     <div class="First-slide-container">
         <img id="slide-left" class="arrow" src="images/arrow-left.png">
         <section class="container-firstproduct-Slider" id="First-slider">

             <div class="First-thumbnail">
                 <img src="./images/product slider/Celrax LED Touch Lamp Bluetooth Speaker.png" alt="">
                 <div class="product-details-one">
                     <h2>Celrax Lamp Bluetooth</h2>

                     <p><span>₹3435</span>₹2567
                     </p>
                     <a href="ProductPage/speakers/cerlax lamp bluetooth.php">Read More</a>

                 </div>
             </div>
             <div class="First-thumbnail">
                 <img src="./images/product slider/HP Chromebook 14inch (5)1.jpg" alt="">

                 <div class="product-details-one">
                     <h2>HP Chromebook</h2>
                     <p> <span>₹28,990.00</span>₹27,990.00</p>

                     <a href="ProductPage/laptop/HP Chromebook Intel Core.php">Read More</a>
                 </div>
             </div>
             <div class="First-thumbnail">
                 <img src="./images/product slider/inspiron14 laptop.png" alt="">
                 <div class="product-details-one">
                     <h2>inspiron14 laptop</h2>
                     <p> <span>₹60,000</span>₹57,989</p>

                     <a href="ProductPage/laptop/Inspiron 14 Laptop.php">Read More</a>
                 </div>
             </div>
             <div class="First-thumbnail">
                 <img src="./images/product slider/iphone12pm (1).jpg" alt="">

                 <div class="product-details-one">
                     <h2>iPhone 12 Pro Max</h2>
                     <p> <span>₹1,29,900</span>₹1,27,890</p>

                     <a href="ProductPage/Smartphones/iphone12promax.php">Read More</a>
                 </div>
             </div>
             <div class="First-thumbnail">
                 <img src="./images/product slider/OnePlus 138.7 cm Tv.png" alt="">
                 <div class="product-details-one">
                     <h2>
                         OnePlus U Series Tv</h2>
                     <p> <span>₹59,999</span>₹52,999</p>

                     <a href="ProductPage/Tv/OnePlus U Series TV.php">Read More</a>
                 </div>
             </div>
             <div class="First-thumbnail">
                 <img src="./images/product slider/Samsung Galaxy M31.png" alt="">
                 <div class="product-details-one">
                     <h2>Samsung Galaxy M31</h2>
                     <p> <span>₹19,999</span> ₹14,999</p>

                     <a href="ProductPage/Smartphones/Samsung Galaxy M31s.php">Read More</a>
                 </div>
             </div>
             <div class="First-thumbnail">
                 <img src="./images/product slider/OPPO A74 5Gt.png" alt="">
                 <div class="product-details-one">
                     <h2>OPPO A74 5Gt</h2>
                     <p> <span>₹20,990</span>₹17,990</p>

                     <a href="ProductPage/Smartphones/OPPO A74 5G.php">Read More</a>
                 </div>
             </div>
             <div class="First-thumbnail">
                 <img src="./images/product slider/AmazonBasics 4K TV.png" alt="">
                 <div class="product-details-one">
                     <h2>AmazonBasics 4K TV</h2>
                     <p> <span>₹50,000</span>₹28,999</p>

                     <a href="ProductPage/Tv/AmazonBasics LED TV.php">Read More</a>
                 </div>
             </div>
             <div class="First-thumbnail">
                 <img src="./images/product slider/Logitech G102 Mouse.png" alt="">
                 <div class="product-details-one">
                     <h2>Logitech G102 Mouse</h2>
                     <p> <span>₹1,995</span> ₹1,645</p>

                     <a href="ProductPage/Mouse/Logitech G102 Mouse.php">Read More</a>
                 </div>
             </div>
             <div class="First-thumbnail">
                 <img src="./images/product slider/Zebronics Zeb-Thunder.png" alt="">
                 <div class="product-details-one">
                     <h2>Zebronics Zeb-Thunder </h2>
                     <p> <span>₹1,199</span>₹735</p>

                     <a href="ProductPage/HeadPhones/Zebronics Zeb-Thunder.php">Read More</a>
                 </div>
             </div>
             <div class="First-thumbnail">
                 <img src="./images/product slider/p4i2m.jpg" alt="">

                 <div class="product-details-one">
                     <h2>HP Ink Tank 319 </h2>
                     <p> <span>₹10,790</span>₹11,790</p>

                     <a href="ProductPage/Printers/HP Ink Tank 319.php">Read More</a>
                 </div>
             </div>
         </section>
         <img id="slide-right" class="arrow" src="images/arrow-right.png">
     </div>
 </section>
<link rel="stylesheet" type="text/css" href="Css/MainPageCss/MpCards.css?v=<?php echo time(); ?>">
<section class="container-content-part2">
    <div class="ui-card2">
        <img src="images/card3/Panasonic 8.0 Kg 5 Star.jpg">
        <div class="description2">
            <h3>Panasonic 8.0 Kg 5 Star </h3>
            <p>Wifi Enabled Fully-Automatic Front Load Inverter Washing Machine: Affordable with great wash quality</p>
            <a href="ProductPage/WashingMachines/SAMSUNG-Washing-Machine.php">Read More</a>
        </div>
    </div>
    <div class="ui-card2">
        <img src="images/card3/Redmi-Note-10S.jpg">
        <div class="description2">
            <h3>Redmi Note 10S.jpg </h3>
            <p>Display: FHD+ (1080x2400) AMOLED Dot display; 16.33 centimeters (6.43 inch); 20:9 aspect ratio.</p>
            <a href="ProductPage/Smartphones/Redmi Note 10S.php">Read More</a>
        </div>
    </div>
    <div class="ui-card2">
        <img src="images/card3/Lenovo-Legion-M200.jpg">
        <div class="description2">
            <h3>Lenovo Legion-M200</h3>
            <p>The Lenovo Legion M200 RGB Gaming Mouse is designed for the beginners and amateur PC gamers</p>
            <a href="ProductPage/Mouse/Lenovo Legion-M200.php">Read More</a>
        </div>
    </div>
    <div class="ui-card2">
        <img src="images/card3/HP-DeskJet--Printer.jpg">
        <div class="description2">
            <h3>HP Deskjet Ink 2778</h3>
            <p>Contact Image Sensor (CIS) with Flatbed Scanner
                Easy Setup having print, copy and scan functions.</p>
            <a href="ProductPage/Printers/HP DeskJet Printer.php" class="ReadmoreProduct">Read More</a>
        </div>
    </div>
</section>
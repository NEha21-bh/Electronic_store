<link rel="stylesheet" type="text/css" href="Css/MainPageCss/MpCards.css?v=<?php echo time(); ?>">
<section class="container-content">
    <div class="ui-card">
        <img src="images/MainPageImage/Mrow1image/Apple iPhone 11 (64gb).jpg">
        <div class="description">
            <h3>Apple iPhone 11 (64gb)</h3>
            <p>Liquid Retina HD display
                6.1-inch (diagonal) all-screen LCD
                Multi-Touch display with IPS technology
            </p>
            <a href="ProductPage/Smartphones/iphone11.php">Read More</a>
        </div>
    </div>
    <div class="ui-card">
        <img src="images/MainPageImage/Mrow1image/EKSA-Stereo-Headset.jpg">
        <div class="description">
            <h3>EKSA Stereo Headset </h3>
            <p>EKSA blue gaming headphones works great with all NEW Xbox One controllers , PS4 and compatible mobile/tablet </p>
            <a href="ProductPage/HeadPhones/EKSA Stereo Headset.php">Read More</a>
        </div>
    </div>
    <div class="ui-card">
        <img src="images/MainPageImage/Mrow1image/Logitech-M337-Mouse.jpg">
        <div class="description">
            <h3>Logitech M337 Mouse</h3>
            <p>Use with virtually any Bluetooth enabled computer, laptop or tablet: Connects to Mac, Windows, Chrome OS and Android.</p>
            <a href="ProductPage/Mouse/Logitech M337 Mouse.php">Read More</a>
        </div>
    </div>
    <div class="ui-card">
        <img src="images/MainPageImage/Mrow1image/OnePlusY Series TV.jpg">
        <div class="description">
            <h3>OnePlusY Series TV</h3>
            <p>Resolution: HD Ready (1366x768) | Refresh Rate: 60 hertz
                Connectivity: 2 HDMI ports to connect set top box</p>
            <a href="ProductPage/Tv/OnePlusY Series TV.php" class="ReadmoreProduct">Read More</a>
        </div>
    </div>
</section>
<section class="container-contentpart2">
    <div class="container-content2">
        <div class="Cimage1">
            <a href="CategoryPages/Refrigerator_MainPage.php"><img src="images/card2/washingM.jpg"></a>

        </div>
        <div class="Cimage1">
            <a href="CategoryPages/Headphones_Main_Page.php"><img src="images/card2/headphones.jpg"></a>

        </div>
        <div class="Cimage1">
            <a href="CategoryPages/Smartphones Main Page.php"><img src="images/card2/phones.jpg"></a>

        </div>
    </div>

</section>